import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class AlertSystem extends AlertSystemBase {

    private final Map<User, HashSet<User>> system;

    public AlertSystem() {
        system = new HashMap<>();
    }

    @Override
    public boolean addPerson(User person) {
        if (system.containsKey(person)) {
            return false;
        }
        system.put(person, new HashSet<>());
        return true;
    }

    @Override
    public boolean removePerson(User person) {
        if (!system.containsKey(person)) {
            return false;
        }
        for (User vertex : system.keySet()) {
            if (system.get(vertex).contains(person)) {
                removeContact(person, vertex);
            }
        }
        system.remove(person);
        return true;
    }

    @Override
    public boolean addContact(User person1, User person2) {
        if (!system.containsKey(person1) || !system.containsKey(person2)) {
            return false;
        }
        system.get(person1).add(person2);
        system.get(person2).add(person1);
        return true;
    }

    @Override
    public int countContacts(User person) {
        if (!system.containsKey(person)) {
            return -1;
        }
        return system.get(person).size();
    }

    @Override
    public boolean removeContact(User person1, User person2) {
        if (!system.getOrDefault(person1, new HashSet<>()).contains(person2)
                || !system.getOrDefault(person2, new HashSet<>()).contains(person1)) {
            return false;
        }
        system.get(person1).remove(person2);
        system.get(person2).remove(person1);
        return true;
    }

    @Override
    public void markInfected(User infectedPerson, int virusDegree) {
        infectedPerson.gotVirus();
        if (virusDegree > 0) {
            var neighbours = system.get(infectedPerson);
            if (neighbours == null) {
                return;
            }
            for (var neighbour : neighbours) {
                markInfected(neighbour, virusDegree - 1);
            }
        }
    }

    public static void main(String[] args) {
        /*
         * Public tests
         */
        {
            AlertSystem alertSystem = new AlertSystem();
            User u1 = new User("Alex");
            User u2 = new User("Max");
            User u3 = new User("Nick");
            User u4 = new User("Bing");
            User[] users = new User[] { u1, u2, u3, u4 };
            for (User user : users) {
                alertSystem.addPerson(user);
            }
            alertSystem.addContact(u1, u2);
            alertSystem.addContact(u1, u3);
            alertSystem.addContact(u2, u4);
            assert alertSystem.countContacts(u1) == 2;
            alertSystem.markInfected(u1, 1);
            assert u1.isInfected();
            assert u2.isInfected();
            assert !u4.isInfected();
        }

        /*
         * Hidden tests
         */
        // Twice the same person
        {
            AlertSystem alertSystem = new AlertSystem();
            User user1 = new User("Nina");
            assert alertSystem.addPerson(user1);
            assert !alertSystem.addPerson(user1);
        }

        // Remove person
        {
            AlertSystem alertSystem = new AlertSystem();
            User u1 = new User("Alex");
            User u2 = new User("Max");
            User u3 = new User("Nick");
            User u4 = new User("Bing");
            User[] users = new User[] { u1, u2, u3, u4 };
            for (User user : users) {
                alertSystem.addPerson(user);
            }
            alertSystem.addContact(u1, u2);
            alertSystem.addContact(u1, u3);
            alertSystem.removePerson(u1);
            assert alertSystem.countContacts(u2) == 0;
            assert alertSystem.countContacts(u3) == 0;
        }

        // Remove contact 1
        {
            AlertSystem alertSystem = new AlertSystem();
            User u1 = new User("Alex");
            User u2 = new User("Max");
            User u3 = new User("Nick");
            User u4 = new User("Bing");
            User[] users = new User[] { u1, u2, u3, u4 };
            for (User user : users) {
                alertSystem.addPerson(user);
            }
            alertSystem.addContact(u1, u2);
            alertSystem.addContact(u1, u3);
            alertSystem.addContact(u2, u3);
            alertSystem.removeContact(u1, u2);
            assert alertSystem.countContacts(u1) == 1;
            assert alertSystem.countContacts(u2) == 1;
            assert alertSystem.countContacts(u3) == 2;
        }

        // Remove contact 2
        {
            AlertSystem alertSystem = new AlertSystem();
            User u1 = new User("Alex");
            User u2 = new User("Max");
            User u3 = new User("Nick");
            User u4 = new User("Bing");
            User[] users = new User[] { u1, u2, u3, u4 };
            for (User user : users) {
                alertSystem.addPerson(user);
            }
            alertSystem.addContact(u1, u2);
            alertSystem.addContact(u1, u2);
            alertSystem.removeContact(u1, u2);
            assert alertSystem.countContacts(u1) == 0;
            boolean stillPresent = alertSystem.removeContact(u1, u2);
            assert !stillPresent;
        }

        // Infected
        {
            AlertSystem alertSystem = new AlertSystem();
            User u1 = new User("Alex");
            User u2 = new User("Max");
            User u3 = new User("Nick");
            User u4 = new User("Bing");
            User u5 = new User("Lena");
            User u6 = new User("Sofa");
            User u7 = new User("Nina");
            User[] users = new User[] { u1, u2, u3, u4, u5, u6, u7 };
            for (User user : users) {
                alertSystem.addPerson(user);
            }
            alertSystem.addContact(u1, u2);
            alertSystem.addContact(u1, u3);
            alertSystem.addContact(u1, u4);
            alertSystem.addContact(u2, u5);
            alertSystem.addContact(u2, u3);
            alertSystem.addContact(u3, u4);
            alertSystem.addContact(u5, u6);
            alertSystem.addContact(u6, u7);
            assert alertSystem.countContacts(u1) == 3;
            alertSystem.markInfected(u1, 2);
            assert u1.isInfected();
            assert u2.isInfected();
            assert u3.isInfected();
            assert !u7.isInfected();
        }
    }
}
